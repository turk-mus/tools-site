// يجلب الترندات كل 30 دقيقة ويخزنها في Netlify Blobs
// يدعم: X_TRENDS_URL (+Bearer) أو RapidAPI عبر RAPIDAPI_KEY + TRENDS_HOST
import { getStore } from '@netlify/blobs';

function isClean(text = '') {
  const bad = ['porn','sex','xxx','nsfw','fuck','shit','rape',
    'قذف','اباح','جنس','سكس','شاذ','زب','كس','طيز','لعن'];
  const s = text.toLowerCase();
  return !bad.some(w => s.includes(w));
}

// مسارات محتملة لجانب RapidAPI (نجربها مرة واحدة فقط ثم نحفظ الأنسب)
const CANDIDATE_PATHS = [
  '/trends?country=',
  '/country_trends?country=',
  '/country-trends?country=',
  '/country?country=',
  '/trending?country=',
  '/api/trends?country=',
  '/v1/trends?country='
];

function buildHeaders() {
  const h = { Accept: 'application/json' };
  if (process.env.X_TRENDS_API_KEY) h.Authorization = `Bearer ${process.env.X_TRENDS_API_KEY}`;
  if (process.env.RAPIDAPI_KEY && process.env.TRENDS_HOST) {
    h['X-RapidAPI-Key'] = process.env.RAPIDAPI_KEY;
    h['X-RapidAPI-Host'] = process.env.TRENDS_HOST;
  }
  return h;
}

async function resolveUpstreamURL(country, store) {
  // A) مزوّد مباشر عبر X_TRENDS_URL
  if (process.env.X_TRENDS_URL) return `${process.env.X_TRENDS_URL}${encodeURIComponent(country)}`;

  // B) RapidAPI عبر TRENDS_HOST
  if (!process.env.TRENDS_HOST) return null;

  // 1) لو محدد TRENDS_PATH استخدمه مباشرة
  if (process.env.TRENDS_PATH) {
    return `https://${process.env.TRENDS_HOST}${process.env.TRENDS_PATH}${encodeURIComponent(country)}`;
  }

  // 2) جرّب المسارات الشائعة مرة واحدة فقط ثم خزّن المختار
  const metaKey = '__provider.json';
  const saved = await store.get(metaKey);
  if (saved) {
    try {
      const { path } = JSON.parse(saved);
      if (path) return `https://${process.env.TRENDS_HOST}${path}${encodeURIComponent(country)}`;
    } catch {}
  }

  for (const p of CANDIDATE_PATHS) {
    const testURL = `https://${process.env.TRENDS_HOST}${p}${encodeURIComponent(country)}`;
    try {
      const r = await fetch(testURL, { headers: buildHeaders() });
      if (!r.ok) continue;
      const j = await r.json();
      const arr = Array.isArray(j) ? j : (j.trends || j.data || j.result || []);
      if (Array.isArray(arr)) {
        // حفظ المسار المكتشف لمرات التحديث القادمة
        await store.setJSON(metaKey, { path: p, host: process.env.TRENDS_HOST }, {});
        return testURL;
      }
    } catch {}
  }
  return null;
}

export default async () => {
  const country = (process.env.TRENDS_COUNTRY || 'SA').trim();
  const store = getStore('trends');
  const key = `${country}.json`;

  // حماية من تكرار التنفيذ خلال 27 دقيقة
  const existing = await store.get(key);
  if (existing) {
    try {
      const { updated_at } = JSON.parse(existing);
      if (updated_at && (Date.now() - new Date(updated_at).getTime()) < 27 * 60 * 1000) {
        return new Response(null, { status: 204 });
      }
    } catch {}
  }

  const url = await resolveUpstreamURL(country, store);
  if (!url) {
    console.error('No upstream URL. Set X_TRENDS_URL or (RAPIDAPI_KEY + TRENDS_HOST [+ TRENDS_PATH]).');
    return new Response(null, { status: 204 });
  }

  const res = await fetch(url, { headers: buildHeaders() });
  if (!res.ok) { console.error('Upstream error', res.status); return new Response(null, { status: 204 }); }

  const raw = await res.json();
  const arr = Array.isArray(raw) ? raw : (raw.trends || raw.data || raw.result || []);
  const trends = (arr || [])
    .map(t => {
      const name = t.name || t.title || t.query || '';
      const tag  = name?.startsWith('#') ? name : (name ? `#${name}` : '');
      const url  = t.url || t.permalink || (name ? `https://x.com/search?q=${encodeURIComponent(name)}` : '#');
      const vol  = t.tweet_volume ?? t.tweets ?? t.volume ?? null;
      return { name: tag, url, tweet_volume: vol };
    })
    .filter(t => t.name && t.name.startsWith('#'))
    .filter(t => isClean(t.name))
    .slice(0, 50);

  const payload = { country, updated_at: new Date().toISOString(), trends };
  await store.setJSON(key, payload, { metadata: { updated_at: payload.updated_at } });

  return new Response(null, { status: 204 });
};

// كرون كل 30 دقيقة
export const config = { schedule: '*/30 * * * *' };
